#!/bin/bash
RESOURCE_GROUP="honeypotz-rg"
ACR_NAME="honeypotzregistry"
LOCATION="eastus"

az group create --name $RESOURCE_GROUP --location $LOCATION
az acr create --name $ACR_NAME --resource-group $RESOURCE_GROUP --sku Basic
az acr login --name $ACR_NAME
