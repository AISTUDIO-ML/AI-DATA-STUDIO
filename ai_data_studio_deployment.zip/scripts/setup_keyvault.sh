#!/bin/bash
RESOURCE_GROUP="honeypotz-rg"
KEYVAULT_NAME="honeypotz-keyvault"
LOCATION="eastus"

az keyvault create --name $KEYVAULT_NAME --resource-group $RESOURCE_GROUP --location $LOCATION
az keyvault secret set --vault-name $KEYVAULT_NAME --name "example-secret" --value "supersecretvalue"
