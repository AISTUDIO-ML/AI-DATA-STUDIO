#!/bin/bash
RESOURCE_GROUP="honeypotz-rg"
ACR_NAME="honeypotzregistry"
CONTAINER_APP_NAME="ai-data-studio"
ENV_NAME="ai-data-studio-env"
LOCATION="eastus"
IMAGE="$ACR_NAME.azurecr.io/ai-data-studio:latest"

az containerapp env create \
  --name $ENV_NAME \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION \
  --enable-confidential-compute true

az containerapp create \
  --name $CONTAINER_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --environment $ENV_NAME \
  --image $IMAGE \
  --target-port 8000 \
  --ingress external \
  --registry-server $ACR_NAME.azurecr.io \
  --cpu 2 --memory 4Gi \
  --confidential-compute-cce-policy ConfidentialCompute
