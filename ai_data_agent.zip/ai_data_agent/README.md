# AI Data Engineering Agent

This microservice performs data engineering tasks including streaming ingestion, NLP summarization, and classification.

## Features

- REST API with FastAPI
- Kafka streaming support
- NLP summarization and classification
- Unit tests with pytest
- CI/CD with GitHub Actions
- Deployment configs for AWS ECS and Azure Container Apps

## Deployment

### AWS ECS

Use the Dockerfile to build and push the image to Amazon ECR, then deploy using ECS Fargate.

### Azure Container Apps

Use Azure CLI or portal to deploy the Docker image to Azure Container Apps.

## Run Locally

Build and run the Docker container:
