from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_summarize():
    response = client.post("/summarize/", files={"file": ("test.txt", b"This is a long text that needs summarization.")})
    assert response.status_code == 200
    assert "summary" in response.json()

def test_classify():
    response = client.post("/classify/", files={"file": ("test.txt", b"This is a legal document.")}, data={"labels": ["finance", "legal", "health"]})
    assert response.status_code == 200
    assert "classification" in response.json()
