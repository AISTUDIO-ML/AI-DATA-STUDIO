from fastapi import FastAPI, UploadFile, File
from .nlp import summarize_text, classify_text

app = FastAPI()

@app.post("/summarize/")
async def summarize(file: UploadFile = File(...)):
    text = await file.read()
    summary = summarize_text(text.decode())
    return {"summary": summary}

@app.post("/classify/")
async def classify(file: UploadFile = File(...), labels: list[str] = ["finance", "legal", "health"]):
    text = await file.read()
    result = classify_text(text.decode(), labels)
    return {"classification": result}
