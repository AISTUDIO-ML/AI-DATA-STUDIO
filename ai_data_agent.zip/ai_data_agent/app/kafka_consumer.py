from kafka import KafkaConsumer
from .processor import process_data

consumer = KafkaConsumer(
    'data_topic',
    bootstrap_servers='localhost:9092',
    auto_offset_reset='earliest',
    group_id='data-engineering-group'
)

def listen_to_stream():
    for message in consumer:
        process_data(message.value)
