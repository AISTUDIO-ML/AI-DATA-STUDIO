def process_data(data):
    # Placeholder for data processing logic
    print("Processing data:", data)
